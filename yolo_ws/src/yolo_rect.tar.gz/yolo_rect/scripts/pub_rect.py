#!/usr/bin/env python
# coding:utf-8

import rospy
from yolo_rect.msg import Boxes, One_box

if __name__ == '__main__':
    nodeName = "jia_yolo_rect"
    rospy.init_node(nodeName)

    # 创建发布者
    topicName = "/jia_yolo_rect"
    publisher = rospy.Publisher(topicName, Boxes, queue_size=1000)

    rate = rospy.Rate(20)
    index = 0
    while not rospy.is_shutdown():
        a=One_box()
        a.label='people'
        a.conf=0.92
        a.distance=0
        a.x1=150
        a.x2=400
        a.y1=0
        a.y2=300

        b=Boxes()
        b.boxes.append(a)



        a=One_box()
        a.label='people'
        a.conf=0.92
        a.distance=0
        a.x1=300
        a.x2=400
        a.y1=300
        a.y2=500
        b.boxes.append(a)

        publisher.publish(b)

        rate.sleep()
        index += 1

    rospy.spin()