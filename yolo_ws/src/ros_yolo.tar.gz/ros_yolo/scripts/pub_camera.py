#! /usr/bin/env python3


import roslib
import rospy
from std_msgs.msg import Header
from std_msgs.msg import String
from sensor_msgs.msg import CompressedImage
from sensor_msgs.msg import Image
IMAGE_WIDTH=1241
IMAGE_HEIGHT=376
from ros_numpy import msgify
from ros_numpy import numpify
# from cv_bridge import CvBridge

import sys
sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')




import os
import time
import cv2
import torch
from numpy import random
import torch.backends.cudnn as cudnn
import numpy as np
from models.experimental import attempt_load
from utils.general import (
    check_img_size, non_max_suppression, apply_classifier, scale_coords,
    xyxy2xywh, plot_one_box, strip_optimizer, set_logging)
from utils.torch_utils import select_device, load_classifier, time_synchronized

from matplotlib import pyplot as plt

ros_image=0

def image_callback_1(image):
    global ros_image
    #ros_image = np.frombuffer(image.data, dtype=np.uint8).reshape(image.height, image.width, -1)
    ros_image=numpify(image)
    cv_image=cv2.cvtColor(ros_image,cv2.cv2.COLOR_BGR2RGB)
    out=msgify(Image,ros_image,encoding='rgb8')
    cv2.imshow('Image_2_cvImg',cv_image)
    cv2.waitKey(1)
    print('nmsl')
    image_pub.publish(out)
if __name__ == '__main__':
    '''
    模型初始化
    '''
    rospy.init_node('ros_numpy')
    image_topic_1 = "/usb_cam/image_raw"
    rospy.Subscriber(image_topic_1, Image, image_callback_1, queue_size=1, buff_size=52428800)
    image_pub = rospy.Publisher('/ros_numpy_out', Image, queue_size=1)
    #rospy.init_node("yolo_result_out_node", anonymous=True)
    rospy.spin()
