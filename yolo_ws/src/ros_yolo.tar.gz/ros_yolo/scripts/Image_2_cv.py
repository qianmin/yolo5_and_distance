#!/usr/bin/env python
import roslib
import sys
import rospy

from std_msgs.msg import String
from sensor_msgs.msg import Image
# from cv_bridge import CvBridge, CvBridgeError
from cv_bridge import CvBridge, CvBridgeError

# import sys
# sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')
import cv2



ros_image=0
bridge = CvBridge()

def image_callback_1(data):
    
    ros_image=bridge.imgmsg_to_cv2(data, "bgr8")
    cv2.imshow('test',ros_image)
    cv2.waitKey(1)
if __name__ == '__main__':
    print(cv2.__version__)
    rospy.init_node('ros_yolo')
    image_topic_1 = "/usb_cam/image_raw"
    rospy.Subscriber(image_topic_1, Image, image_callback_1, queue_size=1, buff_size=52428800)
    # image_pub = rospy.Publisher('/yolo_result_out', Image, queue_size=1)
    rospy.spin()
